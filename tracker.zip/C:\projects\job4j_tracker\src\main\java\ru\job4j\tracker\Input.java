package ru.job4j.tracker;

public interface Input {
    String askStr(String question);

    int askInt(String question);
}
